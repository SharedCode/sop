﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SopClientTests
{
    [TestClass]
    public class AzureTests
    {
        [TestMethod]
        public void TestAdaptor()
        {
            //Sop.Adaptations.Azure.SystemAdaptor.Instance.CreateFileStream()
        }
        [TestMethod]
        public void TestFileStream()
        {
        }
        [TestMethod]
        public void TestObjectServer()
        {
        }
        [TestMethod]
        public void TestFileSet()
        {
        }
        [TestMethod]
        public void TestFileSetStores()
        {
        }
        [TestMethod]
        public void TestStoreNavigator()
        {
        }
    }
}
