﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SopClientTests
{
    /// <summary>
    /// Summary description for BenchmarkTests
    /// </summary>
    [TestClass]
    public class BenchmarkTests
    {
        public BenchmarkTests()
        {
        }
        [TestMethod]
        public void CompareInsertWithSqlExpressTest()
        {
            
        }
    }
}
