// Scalable Object Persistence (SOP) Framework, by Gerardo Recinto (email: gerardorecinto@Yahoo.com for questions/comments)
// Open Source License: LGPL v2.1
// Have fun Coding! ;)

namespace Sop.Transaction
{
    public enum TransactionRootFailTypes
    {
        RemoveFileFailure,
    }
}